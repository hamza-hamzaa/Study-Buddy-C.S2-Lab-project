#include "realchatclient.h"
#include <QJsonDocument>

RealChatClient::RealChatClient(QObject *parent)
    : IChatClient(parent), socket(new QTcpSocket(this))
{
    connect(socket, &QTcpSocket::connected, this, &RealChatClient::connected);
    connect(socket, &QTcpSocket::disconnected, this, &RealChatClient::disconnected);
    connect(socket, &QTcpSocket::readyRead, this, &RealChatClient::readIncomingData);
    connect(socket, &QTcpSocket::errorOccurred, this, [this](QAbstractSocket::SocketError){
        emit errorOccurred(socket->errorString());
    });
}

void RealChatClient::connectToServer(const QString &host, quint16 port)
{
    socket->connectToHost(host, port);
}

void RealChatClient::sendJson(const QJsonObject &jsonObject)
{
    if(socket->state() == QAbstractSocket::ConnectedState) {
        QJsonDocument doc(jsonObject);
        socket->write(doc.toJson(QJsonDocument::Compact) + '\n');
    }
}

void RealChatClient::readIncomingData()
{
    while(socket->canReadLine()) {
        QByteArray data = socket->readLine().trimmed();
        QJsonParseError error;
        QJsonDocument doc = QJsonDocument::fromJson(data, &error);

        if(error.error == QJsonParseError::NoError && doc.isObject()) {
            emit messageReceived(doc.object());
        } else {
            emit errorOccurred("Invalid JSON received from server.");
        }
    }
}
