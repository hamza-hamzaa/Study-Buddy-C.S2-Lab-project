#include "logincontroller.h"

bool LoginController::isValidId(int id) const
{
    return (id / 10000 < 90026 && id / 10000 > 90019);
}

bool LoginController::isValidEmail(const QString &email) const
{
    return email.endsWith("@aucegypt.edu");
}

bool LoginController::isValidMajor(const QString &major) const
{
    return major != "Major";
}

bool LoginController::isValidName(const QString &name) const
{
    return !name.trimmed().isEmpty();
}
