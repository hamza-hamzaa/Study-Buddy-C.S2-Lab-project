#ifndef REALCHATCLIENT_H
#define REALCHATCLIENT_H

#include "ichatclient.h"
#include <QTcpSocket>

class RealChatClient : public IChatClient
{
    Q_OBJECT
public:
    explicit RealChatClient(QObject *parent = nullptr);

    void connectToServer(const QString &host = "127.0.0.1", quint16 port = 54321) override;
    void sendJson(const QJsonObject &jsonObject) override;

private slots:
    void readIncomingData();

private:
    QTcpSocket *socket;
};

#endif
