#ifndef ICHATCLIENT_H
#define ICHATCLIENT_H

#include <QObject>
#include <QJsonObject>

class IChatClient : public QObject
{
    Q_OBJECT
public:
    explicit IChatClient(QObject *parent = nullptr) : QObject(parent) {}
    virtual ~IChatClient() = default;

    virtual void connectToServer(const QString &host = "127.0.0.1", quint16 port = 54321) = 0;
    virtual void sendJson(const QJsonObject &jsonObject) = 0;

signals:
    void connected();
    void disconnected();
    void messageReceived(const QJsonObject &jsonObject);
    void errorOccurred(const QString &error);
};

#endif
