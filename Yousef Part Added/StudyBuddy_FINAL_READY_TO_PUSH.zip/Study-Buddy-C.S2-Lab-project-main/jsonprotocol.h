#ifndef JSONPROTOCOL_H
#define JSONPROTOCOL_H

#include <QString>

namespace JsonProtocol {
static const QString MESSAGE_TYPE = "message_type";
static const QString ROOM_ID = "room_id";
static const QString USER_NAME = "user_name";
static const QString COURSE_NAME = "course_name";
static const QString MESSAGE = "message";
}

#endif
