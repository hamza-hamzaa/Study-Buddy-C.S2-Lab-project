#include "coursecontroller.h"

bool CourseController::canSelectMoreCourses(int currentCount) const
{
    return currentCount <= MAX_COURSES;
}
