#ifndef COURSECONTROLLER_H
#define COURSECONTROLLER_H

class CourseController
{
public:
    static constexpr int MAX_COURSES = 6;

    bool canSelectMoreCourses(int currentCount) const;
};

#endif
