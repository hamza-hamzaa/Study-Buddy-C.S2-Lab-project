#ifndef LOGINCONTROLLER_H
#define LOGINCONTROLLER_H

#include <QString>

class LoginController
{
public:
    bool isValidId(int id) const;
    bool isValidEmail(const QString &email) const;
    bool isValidMajor(const QString &major) const;
    bool isValidName(const QString &name) const;
};

#endif
